/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterfaceGrafica;

import java.util.Arrays;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import sun.audio.*;
import java.io.*;

/**
 *
 * @author paulo.hbezerra
 */
//FUNCAO QUE DEFINE O NAIPE DA CARTA
public class TelaInicial extends javax.swing.JFrame {

    static String NaipeFunction(int NaipeNumeroJogador) {
        String Naipe;
        switch (NaipeNumeroJogador) {

            case 0:
                Naipe = "♠";
                break;
            case 1:
                Naipe = "♣";
                break;
            case 2:
                Naipe = "♥";
                break;
            default:
                Naipe = "♦";
                break;

        }
        return Naipe;
    }

    //FUNCAO QUE RETORNA A IMAGEM A CARTA
    static ImageIcon RetornaCarta(String CartaNaipe) {

        ImageIcon CARTA = new ImageIcon();
        switch (CartaNaipe) {

            //Ouros
            case "1♦":
                CARTA = new ImageIcon("Images/As_Ouros.png");
                break;
            case "2♦":
                CARTA = new ImageIcon("Images/2_Ouros.png");
                break;
            case "3♦":
                CARTA = new ImageIcon("Images/3_Ouros.png");
                break;
            case "4♦":
                CARTA = new ImageIcon("Images/4_Ouros.png");
                break;
            case "5♦":
                CARTA = new ImageIcon("Images/5_Ouros.png");
                break;
            case "6♦":
                CARTA = new ImageIcon("Images/6_Ouros.png");
                break;
            case "7♦":
                CARTA = new ImageIcon("Images/7_Ouros.png");
                break;
            case "8♦":
                CARTA = new ImageIcon("Images/8_Ouros.png");
                break;
            case "9♦":
                CARTA = new ImageIcon("Images/9_Ouros.png");
                break;
            case "10♦":
                CARTA = new ImageIcon("Images/10_Ouros.png");
                break;
            case "10♦VALETE":
                CARTA = new ImageIcon("Images/Valete_Ouros.png");
                break;
            case "10♦DAMA":
                CARTA = new ImageIcon("Images/Dama_Ouros.png");
                break;
            case "10♦REI":
                CARTA = new ImageIcon("Images/Rei_Ouros.png");
                break;

            //Espadas   
            case "1♠":
                CARTA = new ImageIcon("Images/As_Espadas.png");
                break;
            case "2♠":
                CARTA = new ImageIcon("Images/2_Espadas.png");
                break;
            case "3♠":
                CARTA = new ImageIcon("Images/3_Espadas.png");
                break;
            case "4♠":
                CARTA = new ImageIcon("Images/4_Espadas.png");
                break;
            case "5♠":
                CARTA = new ImageIcon("Images/5_Espadas.png");
                break;
            case "6♠":
                CARTA = new ImageIcon("Images/6_Espadas.png");
                break;
            case "7♠":
                CARTA = new ImageIcon("Images/7_Espadas.png");
                break;
            case "8♠":
                CARTA = new ImageIcon("Images/8_Espadas.png");
                break;
            case "9♠":
                CARTA = new ImageIcon("Images/9_Espadas.png");
                break;
            case "10♠":
                CARTA = new ImageIcon("Images/10_Espadas.png");
                break;
            case "10♠VALETE":
                CARTA = new ImageIcon("Images/Valete_Espadas.png");
                break;
            case "10♠DAMA":
                CARTA = new ImageIcon("Images/Dama_Espadas.png");
                break;
            case "10♠REI":
                CARTA = new ImageIcon("Images/Rei_Espadas.png");
                break;

            //Copas
            case "1♥":
                CARTA = new ImageIcon("Images/As_Copas.png");
                break;
            case "2♥":
                CARTA = new ImageIcon("Images/2_Copas.png");
                break;
            case "3♥":
                CARTA = new ImageIcon("Images/3_Copas.png");
                break;
            case "4♥":
                CARTA = new ImageIcon("Images/4_Copas.png");
                break;
            case "5♥":
                CARTA = new ImageIcon("Images/5_Copas.png");
                break;
            case "6♥":
                CARTA = new ImageIcon("Images/6_Copas.png");
                break;
            case "7♥":
                CARTA = new ImageIcon("Images/7_Copas.png");
                break;
            case "8♥":
                CARTA = new ImageIcon("Images/8_Copas.png");
                break;
            case "9♥":
                CARTA = new ImageIcon("Images/9_Copas.png");
                break;
            case "10♥":
                CARTA = new ImageIcon("Images/10_Copas.png");
                break;
            case "10♥VALETE":
                CARTA = new ImageIcon("Images/Valete_Copas.png");
                break;
            case "10♥DAMA":
                CARTA = new ImageIcon("Images/Dama_Copas.png");
                break;
            case "10♥REI":
                CARTA = new ImageIcon("Images/Rei_Copas.png");
                break;

            //Paus
            case "1♣":
                CARTA = new ImageIcon("Images/As_Paus.png");
                break;
            case "2♣":
                CARTA = new ImageIcon("Images/2_Paus.png");
                break;
            case "3♣":
                CARTA = new ImageIcon("Images/3_Paus.png");
                break;
            case "4♣":
                CARTA = new ImageIcon("Images/4_Paus.png");
                break;
            case "5♣":
                CARTA = new ImageIcon("Images/5_Paus.png");
                break;
            case "6♣":
                CARTA = new ImageIcon("Images/6_Paus.png");
                break;
            case "7♣":
                CARTA = new ImageIcon("Images/7_Paus.png");
                break;
            case "8♣":
                CARTA = new ImageIcon("Images/8_Paus.png");
                break;
            case "9♣":
                CARTA = new ImageIcon("Images/9_Paus.png");
                break;
            case "10♣":
                CARTA = new ImageIcon("Images/10_Paus.png");
                break;
            case "10♣VALETE":
                CARTA = new ImageIcon("Images/Valete_Paus.png");
                break;
            case "10♣DAMA":
                CARTA = new ImageIcon("Images/Dama_Paus.png");
                break;
            case "10♣REI":
                CARTA = new ImageIcon("Images/Rei_Paus.png");
                break;
            default:
                CARTA = new ImageIcon("Images/Teste.png");
                System.out.println(CartaNaipe);
                break;
        }
        return CARTA;

    }

    static String baralho[] = new String[5];
    static String baralhoMesa[] = new String[5];
    static String Jogador1, JogadaUser = "";
    static boolean cartavalida;
    static int i = 0;
    static int cartasjogador = 2, cartasmaquina = 2;
    static int rodada = 1;
    static int contadorJogador = 0;
    static int contadorMesa = 0;
    static int ValorAposta = 20;
    static int maquinapedeoutra = 0;
    static int NaipeNumeroJogador = 0;
    static int NaipeNumeroMaquina = 0;
    static String Naipe = NaipeFunction(NaipeNumeroJogador);
    static int MaoMesaoutracarta = 0;
    static boolean fimJogo = true;
    static double SaldoJogador = 0;
    static boolean MesaParou = false;
    static boolean JogadorParou = false;
    static boolean iniciarjogo = false;
    static boolean outracarta = false;
    static boolean nomejogadorvalido = false;
    static Random mesa = new Random();
    static int MaoMesa = 0, MaoJogador = 0, MaoMesaNumero = 0, MaoJogadorNumero = 0;
    static ImageIcon Vegas_Baby_Gif = new ImageIcon("Images/Vegas_Baby.gif");

    ImageIcon carta1 = new ImageIcon("Images/Carta_Virada.png");
    ImageIcon carta2 = new ImageIcon("Images/Carta_Virada.png");
    ImageIcon carta3 = new ImageIcon("Images/Carta_Virada.png");
    ImageIcon carta4 = new ImageIcon("Images/Carta_Virada.png");
    ImageIcon carta5 = new ImageIcon("Images/Carta_Virada.png");
    ImageIcon toasty = new ImageIcon("Images/toasty.png");
    ImageIcon Winner = new ImageIcon("Images/Winner.gif");
    ImageIcon Looser = new ImageIcon("Images/Looser.gif");

    ImageIcon PedeOutraCarta;

    //FUNCAO QUE VALIDA SE A CARTA JA SAIU
    static boolean CartaRepetida(String baralho[], int MaoJogador, String Naipe, int contadorJogador) {

        for (i = 0; i < contadorJogador; i++) {

            if (MaoJogador > 10) {
                if (baralho[i].equals(10 + Naipe)) {
                    cartavalida = false;
                    System.out.println("A carta " + MaoJogador + Naipe + " Ja saiu, carta valida = " + cartavalida);
                    break;
                }
            } else {
                if (baralho[i].equals(MaoJogador + Naipe)) {
                    cartavalida = false;
                    System.out.println("A carta " + MaoJogador + Naipe + " Ja saiu, carta valida = " + cartavalida);
                    break;
                } else {
                    cartavalida = true;
                    System.out.println("A carta " + MaoJogador + Naipe + " nao saiu ainda");
                }

            }
        }
        return cartavalida;

    }

    /**
     * Creates new form TelaInicial
     */
    public TelaInicial() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Carta1titulo = new javax.swing.JLabel();
        Carta2titulo = new javax.swing.JLabel();
        OutraCarta = new javax.swing.JButton();
        FicarJogada = new javax.swing.JButton();
        Carta3titulo = new javax.swing.JLabel();
        Carta4titulo = new javax.swing.JLabel();
        Carta5titulo = new javax.swing.JLabel();
        BotaoIniciar = new javax.swing.JButton();
        ReiniciarJogo = new javax.swing.JButton();
        ImagemCarta1 = new javax.swing.JLabel();
        ImagemCarta2 = new javax.swing.JLabel();
        ImagemCarta3 = new javax.swing.JLabel();
        ImagemCarta4 = new javax.swing.JLabel();
        ImagemCarta5 = new javax.swing.JLabel();
        VegasLetreiro = new javax.swing.JLabel();
        NomeJogador1 = new javax.swing.JLabel();
        Status = new javax.swing.JLabel();
        SubirAposta = new javax.swing.JButton();
        DisplayAposta = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        SaldoTela = new javax.swing.JLabel();
        Toastyy = new javax.swing.JLabel();
        WinnerDisplay = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(10, 192, 156));
        getContentPane().setLayout(null);

        Carta1titulo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Carta1titulo.setForeground(new java.awt.Color(255, 255, 255));
        Carta1titulo.setText("Carta 1");
        getContentPane().add(Carta1titulo);
        Carta1titulo.setBounds(80, 250, 60, 17);

        Carta2titulo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Carta2titulo.setForeground(new java.awt.Color(255, 255, 255));
        Carta2titulo.setText("Carta 2");
        getContentPane().add(Carta2titulo);
        Carta2titulo.setBounds(230, 250, 60, 17);

        OutraCarta.setText("Outra Carta/Hit");
        OutraCarta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OutraCartaActionPerformed(evt);
            }
        });
        getContentPane().add(OutraCarta);
        OutraCarta.setBounds(610, 500, 120, 30);

        FicarJogada.setText("Ficar/Stand");
        FicarJogada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FicarJogadaActionPerformed(evt);
            }
        });
        getContentPane().add(FicarJogada);
        FicarJogada.setBounds(610, 450, 120, 30);

        Carta3titulo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Carta3titulo.setForeground(new java.awt.Color(255, 255, 255));
        Carta3titulo.setText("Carta 3");
        getContentPane().add(Carta3titulo);
        Carta3titulo.setBounds(380, 250, 60, 17);

        Carta4titulo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Carta4titulo.setForeground(new java.awt.Color(255, 255, 255));
        Carta4titulo.setText("Carta 4");
        getContentPane().add(Carta4titulo);
        Carta4titulo.setBounds(530, 250, 60, 17);

        Carta5titulo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Carta5titulo.setForeground(new java.awt.Color(255, 255, 255));
        Carta5titulo.setText("Carta 5");
        getContentPane().add(Carta5titulo);
        Carta5titulo.setBounds(680, 250, 60, 17);

        BotaoIniciar.setText("Iniciar/Start Game");
        BotaoIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoIniciarActionPerformed(evt);
            }
        });
        getContentPane().add(BotaoIniciar);
        BotaoIniciar.setBounds(50, 450, 160, 30);

        ReiniciarJogo.setText("Reiniciar/Restart");
        ReiniciarJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReiniciarJogoActionPerformed(evt);
            }
        });
        getContentPane().add(ReiniciarJogo);
        ReiniciarJogo.setBounds(660, 40, 120, 30);
        getContentPane().add(ImagemCarta1);
        ImagemCarta1.setBounds(50, 260, 120, 150);
        getContentPane().add(ImagemCarta2);
        ImagemCarta2.setBounds(200, 260, 120, 150);
        getContentPane().add(ImagemCarta3);
        ImagemCarta3.setBounds(350, 260, 120, 150);
        getContentPane().add(ImagemCarta4);
        ImagemCarta4.setBounds(500, 260, 120, 150);
        getContentPane().add(ImagemCarta5);
        ImagemCarta5.setBounds(650, 260, 120, 150);
        getContentPane().add(VegasLetreiro);
        VegasLetreiro.setBounds(110, 40, 570, 230);

        NomeJogador1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        NomeJogador1.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(NomeJogador1);
        NomeJogador1.setBounds(370, 460, 230, 30);

        Status.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Status.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(Status);
        Status.setBounds(320, 520, 190, 30);

        SubirAposta.setText("Subir Aposta/Double");
        SubirAposta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubirApostaActionPerformed(evt);
            }
        });
        getContentPane().add(SubirAposta);
        SubirAposta.setBounds(50, 500, 160, 30);

        DisplayAposta.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        DisplayAposta.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(DisplayAposta);
        DisplayAposta.setBounds(240, 490, 80, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Valor Aposta");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(230, 460, 120, 20);

        SaldoTela.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        SaldoTela.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(SaldoTela);
        SaldoTela.setBounds(270, 570, 310, 30);
        getContentPane().add(Toastyy);
        Toastyy.setBounds(630, 510, 170, 120);
        getContentPane().add(WinnerDisplay);
        WinnerDisplay.setBounds(170, 340, 510, 300);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/InterfaceGrafica/background.jpg"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 800, 630);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void OutraCartaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OutraCartaActionPerformed

        if (iniciarjogo == true) {

            if (cartasjogador < 5) {
                MaoJogador = mesa.nextInt(13) + 1;
                switch (MaoJogador) {
                    case 1:
                        MaoJogadorNumero = MaoJogadorNumero + 1;
                        cartasjogador = cartasjogador + 1;
                        NaipeNumeroJogador = mesa.nextInt(3);
                        Naipe = NaipeFunction(NaipeNumeroJogador);
                        cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                        baralho[contadorJogador] = MaoJogador + Naipe;
                        PedeOutraCarta = RetornaCarta(baralho[contadorJogador]);
                        contadorJogador = contadorJogador + 1;
                        break;
                    case 11:
                        MaoJogadorNumero = MaoJogadorNumero + 10;
                        NaipeNumeroJogador = mesa.nextInt(3);
                        cartasjogador = cartasjogador + 1;
                        Naipe = NaipeFunction(NaipeNumeroJogador) + "VALETE";
                        cartavalida = CartaRepetida(baralho, 10, Naipe, contadorJogador);
                        baralho[contadorJogador] = 10 + Naipe;
                        PedeOutraCarta = RetornaCarta(baralho[contadorJogador]);
                        contadorJogador = contadorJogador + 1;
                        break;
                    case 12:
                        MaoJogadorNumero = MaoJogadorNumero + 10;
                        cartasjogador = cartasjogador + 1;
                        NaipeNumeroJogador = mesa.nextInt(3);
                        Naipe = NaipeFunction(NaipeNumeroJogador) + "DAMA";
                        cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                        baralho[contadorJogador] = 10 + Naipe;
                        PedeOutraCarta = RetornaCarta(baralho[contadorJogador]);
                        contadorJogador = contadorJogador + 1;
                        break;
                    case 13:
                        MaoJogadorNumero = MaoJogadorNumero + 10;
                        cartasjogador = cartasjogador + 1;
                        NaipeNumeroJogador = mesa.nextInt(3);
                        Naipe = NaipeFunction(NaipeNumeroJogador) + "REI";
                        cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                        baralho[contadorJogador] = 10 + Naipe;
                        PedeOutraCarta = RetornaCarta(baralho[contadorJogador]);
                        contadorJogador = contadorJogador + 1;
                        break;
                    default:
                        MaoJogadorNumero = MaoJogadorNumero + MaoJogador;
                        cartasjogador = cartasjogador + 1;
                        NaipeNumeroJogador = mesa.nextInt(3);
                        Naipe = NaipeFunction(NaipeNumeroJogador);
                        cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                        baralho[contadorJogador] = MaoJogador + Naipe;
                        PedeOutraCarta = RetornaCarta(baralho[contadorJogador]);
                        contadorJogador = contadorJogador + 1;
                        break;
                }

            }

            if (cartavalida == false) {
                contadorJogador = contadorJogador - 1;
                MaoJogadorNumero = MaoJogadorNumero - MaoJogador;
                Status.setText(String.valueOf("Sua mão tem " + MaoJogadorNumero));
                cartasjogador = cartasjogador - 1;
                OutraCartaActionPerformed(evt);
                System.out.println("PEDI OUTRA AEHOOOOOOOOOOOOOOOOOO");

            }

            if (contadorJogador == 3) {
                ImagemCarta3.setIcon(PedeOutraCarta);

            } else if (contadorJogador == 4) {
                ImagemCarta4.setIcon(PedeOutraCarta);

            } else if (contadorJogador == 5) {
                ImagemCarta5.setIcon(PedeOutraCarta);

            }

            Status.setText(String.valueOf("Sua mão tem " + MaoJogadorNumero));

            if (MaoMesaNumero < 18 && cartasmaquina < 5) {

                maquinapedeoutra = mesa.nextInt(4) + 1;

                if (maquinapedeoutra == 1 || maquinapedeoutra == 2) {
                    MaoMesaoutracarta = mesa.nextInt(13) + 1;
                    JOptionPane.showMessageDialog(null, "A Mesa pediu outra carta");

                    switch (MaoMesaoutracarta) {
                        case 1:
                            MaoMesaNumero = MaoMesaNumero + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina);
                            baralhoMesa[contadorMesa] = MaoMesaoutracarta + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        case 11:
                            MaoMesaNumero = MaoMesaNumero + 10;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina) + "VALETE";
                            ;
                            baralhoMesa[contadorMesa] = 10 + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        case 12:
                            MaoMesaNumero = MaoMesaNumero + 10;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina) + "DAMA";
                            ;
                            baralhoMesa[contadorMesa] = 10 + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        case 13:
                            MaoMesaNumero = MaoMesaNumero + 10;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina) + "REI";
                            baralhoMesa[contadorMesa] = 10 + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        default:
                            MaoMesaNumero = MaoMesaNumero + MaoMesaoutracarta;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina);
                            baralhoMesa[contadorMesa] = MaoMesaoutracarta + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                    }
                } else {
                    // JOptionPane.showMessageDialog(null, "A Mesa passou");
                }

            } else {
                MesaParou = true;
                System.out.println(MesaParou);
            }
            System.out.println("A Mesa tem " + MaoMesaNumero);

            if (MaoJogadorNumero > 21 && MaoMesaNumero <= 21) {
                JOptionPane.showMessageDialog(null, "Você estourou com " + MaoJogadorNumero + " na mão");
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);
                System.out.println("PERDEEEEEEEU 6");

                ReiniciarJogoActionPerformed(evt);

            }
            if (MaoMesaNumero > 21 && MaoJogadorNumero <= 21) {
                JOptionPane.showMessageDialog(null, "Você Ganhou, a Mesa estourou com " + MaoMesaNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);

            }

            if (MaoJogadorNumero == 21 && MaoMesaNumero < 21) {
                JOptionPane.showMessageDialog(null, "Você GANHOU com " + MaoJogadorNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);

            }
            if (MaoMesaNumero == 21 && MaoJogadorNumero < 21 && JogadorParou == true) {
                JOptionPane.showMessageDialog(null, "Você Perdeu com " + MaoJogadorNumero + " na mão e a mesa com " + MaoMesaNumero);
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);
                System.out.println("PERDEEEEEEEU 5");

                ReiniciarJogoActionPerformed(evt);
            }

            if (MaoMesaNumero == 21 && MaoJogadorNumero == 21) {
                JOptionPane.showMessageDialog(null, "Ambos empataram com 21");
                ReiniciarJogoActionPerformed(evt);
            }
            if (MaoMesaNumero > 21 && MaoJogadorNumero > 21) {
                JOptionPane.showMessageDialog(null, "Ambos estouraram com mais de 21");
                ReiniciarJogoActionPerformed(evt);

            }

            //BLOCO TODO MUNDO PAROU
            if (JogadorParou == true && MesaParou == true && MaoJogadorNumero <= 21 && MaoMesaNumero > 21) {
                JOptionPane.showMessageDialog(null, "Você GANHOU com " + MaoJogadorNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero <= 21 && MaoJogadorNumero > 21) {
                JOptionPane.showMessageDialog(null, "Você Perdeu com " + MaoJogadorNumero + " na mão e a mesa com " + MaoMesaNumero);
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);

                System.out.println("PERDEEEEEEEU 4");

                ReiniciarJogoActionPerformed(evt);
            }

            if (JogadorParou == true && MesaParou == true && MaoMesaNumero < 21 && MaoJogadorNumero < 21 && MaoMesaNumero > MaoJogadorNumero) {
                JOptionPane.showMessageDialog(null, "Você Perdeu com " + MaoJogadorNumero + " na mão e a mesa com " + MaoMesaNumero);
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);
                System.out.println("PERDEEEEEEEU 7");
                System.out.println(JogadorParou);

                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero < 21 && MaoJogadorNumero < 21 && MaoJogadorNumero > MaoMesaNumero) {
                JOptionPane.showMessageDialog(null, "Você GANHOU com " + MaoJogadorNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero == 21 && MaoJogadorNumero == 21) {
                JOptionPane.showMessageDialog(null, "Ambos empataram com 21");
                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero == MaoJogadorNumero) {
                JOptionPane.showMessageDialog(null, "Ambos empataram com " + MaoJogadorNumero);
                ReiniciarJogoActionPerformed(evt);
            }

            if (cartasjogador == 5) {
                JOptionPane.showMessageDialog(null, "Você já tem 5 cartas");
            }

            if (cartasmaquina == 5) {

                JOptionPane.showMessageDialog(null, "A Mesa já tem 5 cartas e aguarda sua jogada");
            }


    }//GEN-LAST:event_OutraCartaActionPerformed

    }
    private void BotaoIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoIniciarActionPerformed

        if (iniciarjogo == false) {

            while (nomejogadorvalido == false) {

                Jogador1 = JOptionPane.showInputDialog("Digite o nome do Jogador");

                if (Jogador1.equals("") || Jogador1.equals(" ") || Jogador1.equals("   ")) {
                    JOptionPane.showMessageDialog(null, "Nome do Jogador inválido");
                } else {
                    NomeJogador1.setText(String.valueOf("Jogador " + Jogador1));
                    nomejogadorvalido = true;
                }
            }

            //CARTA 1 JOGADOR
            MaoJogador = mesa.nextInt(13) + 1;
            NaipeNumeroJogador = mesa.nextInt(3);
            switch (MaoJogador) {
                case 1:
                    MaoJogadorNumero = MaoJogadorNumero + 1;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador);
                    baralho[contadorJogador] = MaoJogador + Naipe;
                    carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                case 11:
                    MaoJogadorNumero = MaoJogadorNumero + 10;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador) + "VALETE";
                    baralho[contadorJogador] = 10 + Naipe;
                    carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                case 12:
                    MaoJogadorNumero = MaoJogadorNumero + 10;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador) + "REI";
                    baralho[contadorJogador] = 10 + Naipe;
                    carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                case 13:
                    MaoJogadorNumero = MaoJogadorNumero + 10;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador) + "DAMA";
                    baralho[contadorJogador] = 10 + Naipe;
                    carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                default:
                    MaoJogadorNumero = MaoJogadorNumero + MaoJogador;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador);
                    baralho[contadorJogador] = MaoJogador + Naipe;
                    carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;

            }

            Status.setText(String.valueOf("Sua mão tem " + MaoJogadorNumero));

            //CARTA 2 JOGADOR
            MaoJogador = mesa.nextInt(13) + 1;
            NaipeNumeroJogador = mesa.nextInt(3);
            switch (MaoJogador) {
                case 1:
                    MaoJogadorNumero = MaoJogadorNumero + 1;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador);
                    cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                    baralho[contadorJogador] = MaoJogador + Naipe;
                    carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                case 11:
                    MaoJogadorNumero = MaoJogadorNumero + 10;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador) + "VALETE";
                    cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                    baralho[contadorJogador] = 10 + Naipe;
                    carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                case 12:
                    MaoJogadorNumero = MaoJogadorNumero + 10;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador) + "REI";
                    cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                    baralho[contadorJogador] = 10 + Naipe;
                    carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                case 13:
                    MaoJogadorNumero = MaoJogadorNumero + 10;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador) + "DAMA";
                    cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                    baralho[contadorJogador] = 10 + Naipe;
                    carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;
                default:
                    MaoJogadorNumero = MaoJogadorNumero + MaoJogador;
                    NaipeNumeroJogador = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroJogador);
                    cartavalida = CartaRepetida(baralho, MaoJogador, Naipe, contadorJogador);
                    baralho[contadorJogador] = MaoJogador + Naipe;
                    carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorJogador = contadorJogador + 1;
                    break;

            }

            if (baralho[0] == baralho[1]) {
                BotaoIniciarActionPerformed(evt);
                System.out.println("cartas iguais no inicio o jogo");

            }

            //cartavalida = true;
            Status.setText(String.valueOf("Sua mão tem " + MaoJogadorNumero));

            //CARTA 1 MESA
            MaoMesa = mesa.nextInt(13) + 1;
            NaipeNumeroMaquina = mesa.nextInt(3);
            switch (MaoMesa) {
                case 1:
                    MaoMesaNumero = MaoMesaNumero + 1;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina);
                    baralhoMesa[contadorMesa] = MaoMesa + Naipe;
                    //carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                case 11:
                    MaoMesaNumero = MaoMesaNumero + 10;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina) + "VALETE";
                    baralhoMesa[contadorMesa] = 10 + Naipe;
                    //carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                case 12:
                    MaoMesaNumero = MaoMesaNumero + 10;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina) + "REI";
                    baralhoMesa[contadorMesa] = 10 + Naipe;
                    //carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                case 13:
                    MaoMesaNumero = MaoMesaNumero + 10;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina) + "DAMA";
                    baralhoMesa[contadorMesa] = 10 + Naipe;
                    // carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                default:
                    MaoMesaNumero = MaoMesaNumero + MaoMesa;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina);
                    baralhoMesa[contadorMesa] = MaoMesa + Naipe;
                    //carta1 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;

            }

            System.out.println("A mesa tirou na carta 1 " + MaoMesaNumero);

            //CARTA 2 MESA
            MaoMesa = mesa.nextInt(13) + 1;
            NaipeNumeroMaquina = mesa.nextInt(3);
            switch (MaoMesa) {
                case 1:
                    MaoMesaNumero = MaoMesaNumero + 1;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina);
                    baralhoMesa[contadorMesa] = MaoMesa + Naipe;
                    //carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                case 11:
                    MaoMesaNumero = MaoMesaNumero + 10;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina) + "VALETE";
                    baralhoMesa[contadorMesa] = 10 + Naipe;
                    //carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                case 12:
                    MaoMesaNumero = MaoMesaNumero + 10;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina) + "REI";
                    baralhoMesa[contadorMesa] = 10 + Naipe;
                    //carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                case 13:
                    MaoMesaNumero = MaoMesaNumero + 10;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina) + "DAMA";
                    baralhoMesa[contadorMesa] = 10 + Naipe;
                    // carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;
                default:
                    MaoMesaNumero = MaoMesaNumero + MaoMesa;
                    NaipeNumeroMaquina = mesa.nextInt(3);
                    Naipe = NaipeFunction(NaipeNumeroMaquina);
                    baralhoMesa[contadorMesa] = MaoMesa + Naipe;
                    //carta2 = RetornaCarta(baralho[contadorJogador]);
                    contadorMesa = contadorMesa + 1;
                    break;

            }

            System.out.println("A Mesa tirou na carta 2 " + MaoMesaNumero);

            Status.setText(String.valueOf("Sua mão tem " + MaoJogadorNumero));
            ImagemCarta1.setIcon(carta1);
            ImagemCarta2.setIcon(carta2);
            ImagemCarta3.setIcon(carta3);
            ImagemCarta4.setIcon(carta4);
            ImagemCarta5.setIcon(carta5);

            //EASTER EGG
            if (Jogador1.equals("Paulo") || Jogador1.equals("Andre") || Jogador1.equals("Lucas") || Jogador1.equals("Ramon")) {
                Toastyy.setIcon(toasty);

            }

            DisplayAposta.setText(String.valueOf("R$" + ValorAposta));

        }

        if (cartavalida == false) {

            if (rodada > 0) {
                rodada = rodada - 1;
            }
            ReiniciarJogoActionPerformed(evt);
            System.out.println("CARTA REPETIDA AEHOOOOOOOOOOOOOOOOOO REINICIEI");
        }

        VegasLetreiro.setIcon(Vegas_Baby_Gif);

        iniciarjogo = true;

        //System.out.println("carta valida = " + cartavalida);

    }//GEN-LAST:event_BotaoIniciarActionPerformed

    private void ReiniciarJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReiniciarJogoActionPerformed

        iniciarjogo = false;
        nomejogadorvalido = true;
        rodada = rodada + 1;

        cartasjogador = 0;
        cartasmaquina = 0;
        contadorMesa = 0;
        contadorJogador = 0;
        JogadorParou = false;
        MesaParou = false;

        Status.setText(String.valueOf(" "));
        ValorAposta = 20;
        MaoJogadorNumero = 0;
        MaoMesaNumero = 0;

        // NomeJogador1.setText(String.valueOf(""));
        for (int i = 0; i < baralho.length; i++) {
            baralho[i] = " ";
        }

        for (int i = 0; i < baralhoMesa.length; i++) {
            baralhoMesa[i] = " ";
        }
        if (rodada > 1) {
            JOptionPane.showMessageDialog(null, "Nova Rodada de número " + rodada);

        }

        WinnerDisplay.setIcon(null);

        BotaoIniciarActionPerformed(evt);


    }//GEN-LAST:event_ReiniciarJogoActionPerformed

    private void FicarJogadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FicarJogadaActionPerformed

        JogadorParou = true;
        System.out.println("Jogador parou " + JogadorParou);
        if (iniciarjogo == true) {

            while (MaoMesaNumero < 18 && cartasmaquina < 5) {

                maquinapedeoutra = mesa.nextInt(4) + 1;

                if (maquinapedeoutra == 1 || maquinapedeoutra == 2) {
                    MaoMesaoutracarta = mesa.nextInt(13) + 1;
                    JOptionPane.showMessageDialog(null, "A maquina pediu outra carta");

                    switch (MaoMesaoutracarta) {
                        case 1:
                            MaoMesaNumero = MaoMesaNumero + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina);
                            baralhoMesa[contadorMesa] = MaoMesaoutracarta + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        case 11:
                            MaoMesaNumero = MaoMesaNumero + 10;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina) + "VALETE";
                            baralhoMesa[contadorMesa] = 10 + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        case 12:
                            MaoMesaNumero = MaoMesaNumero + 10;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina) + "REI";
                            baralhoMesa[contadorMesa] = 10 + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        case 13:
                            MaoMesaNumero = MaoMesaNumero + 10;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina) + "DAMA";
                            baralhoMesa[contadorMesa] = 10 + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                        default:
                            MaoMesaNumero = MaoMesaNumero + MaoMesaoutracarta;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            cartasmaquina = cartasmaquina + 1;
                            NaipeNumeroMaquina = mesa.nextInt(3);
                            Naipe = NaipeFunction(NaipeNumeroMaquina);
                            baralhoMesa[contadorMesa] = MaoMesaoutracarta + Naipe;
                            contadorMesa = contadorMesa + 1;
                            break;
                    }
                } else {
                    //JOptionPane.showMessageDialog(null, "A Mesa passou");
                }
                System.out.println("a maquina tem " + MaoMesaNumero);

            }
            MesaParou = true;
            JOptionPane.showMessageDialog(null, "A Mesa parou de pedir carta");

            if (MaoJogadorNumero > 21 && MaoMesaNumero <= 21) {
                JOptionPane.showMessageDialog(null, "Você estourou com " + MaoJogadorNumero + " na mão");
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);
                ReiniciarJogoActionPerformed(evt);

            }
            if (MaoMesaNumero > 21 && MaoJogadorNumero <= 21) {
                JOptionPane.showMessageDialog(null, "Você Ganhou, a Mesa estourou com " + MaoMesaNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);

            }

            if (JogadorParou == true && MesaParou == true && MaoJogadorNumero == 21 && MaoMesaNumero < 21) {
                JOptionPane.showMessageDialog(null, "Você GANHOU com " + MaoJogadorNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);

            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero == 21 && MaoJogadorNumero < 21) {
                JOptionPane.showMessageDialog(null, "Você Perdeu com " + MaoJogadorNumero + " na mão e a mesa com " + MaoMesaNumero);
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);
                System.out.println("PERDEEEEEEEU 1");
                ReiniciarJogoActionPerformed(evt);
            }

            if (MaoMesaNumero == 21 && MaoJogadorNumero == 21) {
                JOptionPane.showMessageDialog(null, "Ambos empataram com 21");
                ReiniciarJogoActionPerformed(evt);
            }
            if (MaoMesaNumero > 21 && MaoJogadorNumero > 21) {
                JOptionPane.showMessageDialog(null, "Ambos estouraram com mais de 21");
                ReiniciarJogoActionPerformed(evt);

            }

            //BLOCO TODO MUNDO PAROU
            if (JogadorParou == true && MesaParou == true && MaoJogadorNumero <= 21 && MaoMesaNumero > 21) {
                JOptionPane.showMessageDialog(null, "Você GANHOU com " + MaoJogadorNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero <= 21 && MaoJogadorNumero > 21) {
                JOptionPane.showMessageDialog(null, "Você Perdeu com " + MaoJogadorNumero + " na mão e a mesa com " + MaoMesaNumero);
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);
                System.out.println("PERDEEEEEEEU 2");
                ReiniciarJogoActionPerformed(evt);
            }

            if (JogadorParou == true && MesaParou == true && MaoMesaNumero < 21 && MaoJogadorNumero < 21 && MaoMesaNumero > MaoJogadorNumero) {
                JOptionPane.showMessageDialog(null, "Você Perdeu com " + MaoJogadorNumero + " na mão e a mesa com " + MaoMesaNumero);
                SaldoJogador = SaldoJogador - ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Looser);
                System.out.println("PERDEEEEEEEU 3");

                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero < 21 && MaoJogadorNumero < 21 && MaoJogadorNumero > MaoMesaNumero) {
                JOptionPane.showMessageDialog(null, "Você GANHOU com " + MaoJogadorNumero + " na mão. Você faturou R$" + ValorAposta);
                SaldoJogador = SaldoJogador + ValorAposta;
                SaldoTela.setText(String.valueOf("Seu saldo atual é de R$" + SaldoJogador));
                WinnerDisplay.setIcon(Winner);
                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero == 21 && MaoJogadorNumero == 21) {
                JOptionPane.showMessageDialog(null, "Ambos empataram com 21");
                ReiniciarJogoActionPerformed(evt);
            }
            if (JogadorParou == true && MesaParou == true && MaoMesaNumero == MaoJogadorNumero) {
                JOptionPane.showMessageDialog(null, "Ambos empataram com " + MaoJogadorNumero);
                ReiniciarJogoActionPerformed(evt);
            }

            if (cartasjogador == 5) {
                JOptionPane.showMessageDialog(null, "Você já tem 5 cartas");
            }

            if (cartasmaquina == 5) {

                JOptionPane.showMessageDialog(null, "A Mesa já tem 5 cartas e aguarda sua jogada");
            }// TODO add your handling code here:
    }//GEN-LAST:event_FicarJogadaActionPerformed
    }
    private void SubirApostaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubirApostaActionPerformed

        ValorAposta = ValorAposta + 20;

        DisplayAposta.setText(String.valueOf("R$" + ValorAposta));

        // TODO add your handling code here:
    }//GEN-LAST:event_SubirApostaActionPerformed

    public static void main(String args[]) {

        for (int i = 0; i < baralho.length; i++) {
            baralho[i] = " ";
        }

        boolean cartavalida = false;

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                TelaInicial telaInicial = new TelaInicial();
                telaInicial.setSize(820, 670);
                telaInicial.setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotaoIniciar;
    private javax.swing.JLabel Carta1titulo;
    private javax.swing.JLabel Carta2titulo;
    private javax.swing.JLabel Carta3titulo;
    private javax.swing.JLabel Carta4titulo;
    private javax.swing.JLabel Carta5titulo;
    private javax.swing.JLabel DisplayAposta;
    private javax.swing.JButton FicarJogada;
    private javax.swing.JLabel ImagemCarta1;
    private javax.swing.JLabel ImagemCarta2;
    private javax.swing.JLabel ImagemCarta3;
    private javax.swing.JLabel ImagemCarta4;
    private javax.swing.JLabel ImagemCarta5;
    private javax.swing.JLabel NomeJogador1;
    private javax.swing.JButton OutraCarta;
    private javax.swing.JButton ReiniciarJogo;
    private javax.swing.JLabel SaldoTela;
    private javax.swing.JLabel Status;
    private javax.swing.JButton SubirAposta;
    private javax.swing.JLabel Toastyy;
    private javax.swing.JLabel VegasLetreiro;
    private javax.swing.JLabel WinnerDisplay;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
